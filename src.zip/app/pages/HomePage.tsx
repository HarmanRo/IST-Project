import { Link } from "react-router";
import { Button } from "../components/ui/button";
import { Card, CardContent } from "../components/ui/card";
import { ArrowRight, Truck, ShieldCheck, RefreshCw } from "lucide-react";
import { getFeaturedProducts } from "../data/products";
import { ProductCard } from "../components/ProductCard";

export function HomePage() {
  const featuredProducts = getFeaturedProducts();

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 to-blue-800 text-white">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h1 className="text-4xl lg:text-6xl font-bold leading-tight">
                Elevate Your Performance
              </h1>
              <p className="text-lg lg:text-xl text-blue-100">
                Premium athletic gear engineered for champions. From the track to the gym, 
                we've got you covered with cutting-edge technology and unmatched comfort.
              </p>
              <div className="flex flex-wrap gap-4">
                <Button size="lg" asChild className="bg-white text-blue-600 border-2 border-white hover:bg-blue-600 hover:text-white hover:border-white transition-colors">
                  <Link to="/products">
                    Shop Now
                    <ArrowRight className="ml-2 w-4 h-4" />
                  </Link>
                </Button>
                <Button size="lg" asChild className="bg-white text-blue-600 border-2 border-white hover:bg-blue-600 hover:text-white hover:border-white transition-colors">
                  <Link to="/about">Learn More</Link>
                </Button>
              </div>
            </div>
            <div className="relative h-96 lg:h-[500px] rounded-2xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1517836357463-d25dfeac3438?w=800&q=80"
                alt="Athletes training"
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="bg-gray-50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <Card>
              <CardContent className="p-6 text-center space-y-3">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                  <Truck className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-semibold text-lg">Free Shipping</h3>
                <p className="text-sm text-gray-600">
                  Free delivery on all orders over $100
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center space-y-3">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                  <ShieldCheck className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-semibold text-lg">Quality Guarantee</h3>
                <p className="text-sm text-gray-600">
                  Premium materials built to last
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6 text-center space-y-3">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto">
                  <RefreshCw className="w-6 h-6 text-blue-600" />
                </div>
                <h3 className="font-semibold text-lg">Easy Returns</h3>
                <p className="text-sm text-gray-600">
                  30-day return policy, no questions asked
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold mb-8">Shop by Category</h2>
          <div className="grid md:grid-cols-3 gap-6">
            <Link to="/products?category=clothing" className="group relative h-80 rounded-xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1556821840-3a63f95609a7?w=800&q=80"
                alt="Clothing"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-2xl font-bold mb-2">Clothing</h3>
                  <p className="text-sm text-gray-200">Performance apparel for every workout</p>
                </div>
              </div>
            </Link>
            <Link to="/products?category=shoes" className="group relative h-80 rounded-xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=800&q=80"
                alt="Shoes"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-2xl font-bold mb-2">Shoes</h3>
                  <p className="text-sm text-gray-200">Step up your game with premium footwear</p>
                </div>
              </div>
            </Link>
            <Link to="/products?category=accessories" className="group relative h-80 rounded-xl overflow-hidden">
              <img
                src="https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=800&q=80"
                alt="Accessories"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent flex items-end">
                <div className="p-6 text-white">
                  <h3 className="text-2xl font-bold mb-2">Accessories</h3>
                  <p className="text-sm text-gray-200">Essential gear for your training</p>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Products */}
      <section className="bg-gray-50 py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-8">
            <h2 className="text-3xl font-bold">Featured Products</h2>
            <Button variant="outline" asChild>
              <Link to="/products">
                View All
                <ArrowRight className="ml-2 w-4 h-4" />
              </Link>
            </Button>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-r from-blue-600 to-blue-800 rounded-2xl p-12 text-center text-white">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Join Our Athletic Community
            </h2>
            <p className="text-lg text-blue-100 mb-8 max-w-2xl mx-auto">
              Get exclusive access to new releases, training tips, and special offers. 
              Sign up for our newsletter today.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
              <input
                type="email"
                placeholder="Enter your email"
                className="px-4 py-3 rounded-lg flex-1 text-gray-900 bg-blue-50"
                aria-label="Email address"
              />
              <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100">
                Subscribe
              </Button>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}