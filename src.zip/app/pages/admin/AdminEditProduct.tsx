import { useState, useEffect } from "react";
import { useNavigate, useParams, Link } from "react-router";
import { getProductById } from "../../data/products";
import { Button } from "../../components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "../../components/ui/card";
import { Input } from "../../components/ui/input";
import { Label } from "../../components/ui/label";
import { Textarea } from "../../components/ui/textarea";
import { Switch } from "../../components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../../components/ui/select";
import { Separator } from "../../components/ui/separator";
import { Badge } from "../../components/ui/badge";
import { ArrowLeft, Plus, X, History } from "lucide-react";
import { toast } from "sonner";

export function AdminEditProduct() {
  const { id } = useParams();
  const navigate = useNavigate();
  const product = getProductById(id || "");

  const [formData, setFormData] = useState({
    name: "",
    category: "clothing",
    subcategory: "",
    price: "",
    description: "",
    sizes: [] as string[],
    newSize: "",
    colors: [] as string[],
    newColor: "",
    featured: false,
    inStock: true,
    metaTitle: "",
    metaDescription: "",
  });

  useEffect(() => {
    if (product) {
      setFormData({
        name: product.name,
        category: product.category,
        subcategory: product.subcategory,
        price: product.price.toString(),
        description: product.description,
        sizes: product.sizes,
        newSize: "",
        colors: product.colors || [],
        newColor: "",
        featured: product.featured,
        inStock: product.inStock,
        metaTitle: "",
        metaDescription: "",
      });
    }
  }, [product]);

  if (!product) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-bold mb-4">Product not found</h2>
        <Button asChild>
          <Link to="/admin/products">Back to Products</Link>
        </Button>
      </div>
    );
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.price || !formData.description) {
      toast.error("Please fill in all required fields");
      return;
    }

    // Simulate saving
    await new Promise((resolve) => setTimeout(resolve, 1000));

    toast.success("Product updated successfully!");
    navigate("/admin/products");
  };

  const addSize = () => {
    if (formData.newSize && !formData.sizes.includes(formData.newSize)) {
      setFormData({
        ...formData,
        sizes: [...formData.sizes, formData.newSize],
        newSize: "",
      });
    }
  };

  const removeSize = (size: string) => {
    setFormData({
      ...formData,
      sizes: formData.sizes.filter((s) => s !== size),
    });
  };

  const addColor = () => {
    if (formData.newColor && !formData.colors.includes(formData.newColor)) {
      setFormData({
        ...formData,
        colors: [...formData.colors, formData.newColor],
        newColor: "",
      });
    }
  };

  const removeColor = (color: string) => {
    setFormData({
      ...formData,
      colors: formData.colors.filter((c) => c !== color),
    });
  };

  const mockRevisions = [
    { version: 3, date: "2026-02-24 10:30", author: "Admin", changes: "Updated price and description" },
    { version: 2, date: "2026-02-20 14:15", author: "Admin", changes: "Added new sizes" },
    { version: 1, date: "2026-02-15 09:00", author: "Admin", changes: "Initial creation" },
  ];

  return (
    <div className="space-y-6 max-w-4xl">
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="sm" asChild>
          <Link to="/admin/products">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Link>
        </Button>
        <div className="flex-1">
          <h1 className="text-3xl font-bold">Edit Product</h1>
          <p className="text-gray-600 mt-1">Update product information</p>
        </div>
        <Badge variant="secondary">ID: {product.id}</Badge>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="name">
                    Product Name <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="name"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    required
                  />
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="category">
                      Category <span className="text-red-500">*</span>
                    </Label>
                    <Select
                      value={formData.category}
                      onValueChange={(value) => setFormData({ ...formData, category: value })}
                    >
                      <SelectTrigger id="category">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="clothing">Clothing</SelectItem>
                        <SelectItem value="shoes">Shoes</SelectItem>
                        <SelectItem value="accessories">Accessories</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="subcategory">Subcategory</Label>
                    <Input
                      id="subcategory"
                      value={formData.subcategory}
                      onChange={(e) => setFormData({ ...formData, subcategory: e.target.value })}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="price">
                    Price <span className="text-red-500">*</span>
                  </Label>
                  <Input
                    id="price"
                    type="number"
                    step="0.01"
                    min="0"
                    value={formData.price}
                    onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">
                    Description <span className="text-red-500">*</span>
                  </Label>
                  <Textarea
                    id="description"
                    rows={4}
                    value={formData.description}
                    onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                    required
                  />
                </div>
              </CardContent>
            </Card>

            {/* Variants */}
            <Card>
              <CardHeader>
                <CardTitle>Product Variants</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <Label>Sizes</Label>
                  <div className="flex gap-2">
                    <Input
                      value={formData.newSize}
                      onChange={(e) => setFormData({ ...formData, newSize: e.target.value })}
                      placeholder="Add size"
                      onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addSize())}
                    />
                    <Button type="button" onClick={addSize}>
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {formData.sizes.map((size) => (
                      <div
                        key={size}
                        className="flex items-center gap-1 bg-gray-100 px-3 py-1 rounded-lg"
                      >
                        <span>{size}</span>
                        <button
                          type="button"
                          onClick={() => removeSize(size)}
                          className="text-gray-500 hover:text-gray-700"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                <Separator />

                <div className="space-y-2">
                  <Label>Colors</Label>
                  <div className="flex gap-2">
                    <Input
                      value={formData.newColor}
                      onChange={(e) => setFormData({ ...formData, newColor: e.target.value })}
                      placeholder="Add color"
                      onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addColor())}
                    />
                    <Button type="button" onClick={addColor}>
                      <Plus className="w-4 h-4" />
                    </Button>
                  </div>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {formData.colors.map((color) => (
                      <div
                        key={color}
                        className="flex items-center gap-1 bg-gray-100 px-3 py-1 rounded-lg"
                      >
                        <span>{color}</span>
                        <button
                          type="button"
                          onClick={() => removeColor(color)}
                          className="text-gray-500 hover:text-gray-700"
                        >
                          <X className="w-3 h-3" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Settings */}
            <Card>
              <CardHeader>
                <CardTitle>Product Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="featured">Featured Product</Label>
                    <p className="text-sm text-gray-600">Show on homepage</p>
                  </div>
                  <Switch
                    id="featured"
                    checked={formData.featured}
                    onCheckedChange={(checked) => setFormData({ ...formData, featured: checked })}
                  />
                </div>

                <Separator />

                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="inStock">In Stock</Label>
                    <p className="text-sm text-gray-600">Product availability</p>
                  </div>
                  <Switch
                    id="inStock"
                    checked={formData.inStock}
                    onCheckedChange={(checked) => setFormData({ ...formData, inStock: checked })}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Actions */}
            <div className="flex gap-4">
              <Button type="submit" size="lg">
                Update Product
              </Button>
              <Button type="button" variant="outline" size="lg" asChild>
                <Link to="/admin/products">Cancel</Link>
              </Button>
            </div>
          </form>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Product Preview */}
          <Card>
            <CardHeader>
              <CardTitle>Product Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="aspect-square bg-gray-100 rounded-lg overflow-hidden mb-3">
                <img
                  src={product.images[0]}
                  alt={product.name}
                  className="w-full h-full object-cover"
                />
              </div>
              <p className="text-sm text-gray-600">Current product image</p>
            </CardContent>
          </Card>

          {/* Revision History */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <History className="w-4 h-4" />
                Revision History
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {mockRevisions.map((revision) => (
                <div key={revision.version} className="text-sm border-l-2 border-blue-600 pl-3">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant="secondary">v{revision.version}</Badge>
                    <span className="text-xs text-gray-500">{revision.date}</span>
                  </div>
                  <p className="text-gray-600">{revision.changes}</p>
                  <p className="text-xs text-gray-500 mt-1">by {revision.author}</p>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
